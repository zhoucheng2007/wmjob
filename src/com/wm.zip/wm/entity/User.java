package com.wm.entity;
/**
 * 
 * @author zc
 * �û�ʵ�廯��
 */
public class User {

	public String id;
	
	public String name;
	
	public String password;
	
	public String creattime;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getCreattime() {
		return creattime;
	}

	public void setCreattime(String creattime) {
		this.creattime = creattime;
	}
	
	
	
	
}
