package com.wm.entity;

public class Goods {
	String id;
	
	String goodname;
	
	String price;
	
	String createtime;
	
	String shangjiaid;
	
	String shangjianame;
		
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getGoodname() {
		return goodname;
	}

	public void setGoodname(String goodname) {
		this.goodname = goodname;
	}

	public String getPrice() {
		return price;
	}

	public void setPrice(String price) {
		this.price = price;
	}

	public String getCreatetime() {
		return createtime;
	}

	public void setCreatetime(String createtime) {
		this.createtime = createtime;
	}

	public String getShangjiaid() {
		return shangjiaid;
	}

	public void setShangjiaid(String shangjiaid) {
		this.shangjiaid = shangjiaid;
	}

	public String getShangjianame() {
		return shangjianame;
	}

	public void setShangjianame(String shangjianame) {
		this.shangjianame = shangjianame;
	}
	
}
